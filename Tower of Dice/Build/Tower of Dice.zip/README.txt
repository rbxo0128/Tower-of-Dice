Tower of Dice.exe 더블클릭 후 실행

Unity 버전 : 2022.3.23f1